﻿using Microsoft.AspNetCore.Mvc;

namespace PROYECTO_WEB.Controllers
{
    public class SecurityController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
